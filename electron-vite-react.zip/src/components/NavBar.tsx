import React from "react";
import { Link } from "react-router-dom";

const NavBar: React.FC = () => {
  return (
    <div>
      <Link to="/">---Go back</Link>
        <h1 className="bg-red-500"></h1>
    </div>
  );
};

export default NavBar;
